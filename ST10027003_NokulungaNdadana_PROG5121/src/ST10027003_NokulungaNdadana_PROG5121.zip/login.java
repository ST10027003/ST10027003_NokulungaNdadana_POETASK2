
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Nokulunga Ndadana
 */
public class login {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input =new Scanner(System.in);
        System.out.println("Hi there, please enter your  first name");
        String firstname=input.nextLine();
        System.out.println(firstname +  "successfully registered");
        
        System.out.println("Please enter your last name");
        String lastname=input.nextLine();
        System.out.println(lastname +  "successfully registered");
        
        System.out.println("Please enter your username. Username must contain an underscore and is no longer than 5 characters long");
        String username=input.nextLine();
        System.out.println(username +  "successfully registered");
        checkUserName(username);
        
        System.out.println("Please enter your password. Password must contain a capital letter, a digit, a special character and must be atleast 8 characters long");
        String password=input.nextLine();
        System.out.println(password +  "sucessfully registered");
        checkPasswordComplexity (password);
        
       
    }
    public static Scanner input= new Scanner(System.in);
    
    public static boolean checkUserName(String username){
        
        boolean underscore= false;
        boolean limit= false;
        
        for(int u=0 ;u<username.length(); u++) {
        if (username.charAt(u)==95)
           underscore=true;
        }
        if(username.length() <=5) {
            limit=true; 
        }
        if(underscore && limit ==true) {
            System.out.println("Username Sucessfully captured");
        }
        else
        {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length ");
        }
        
        return false;
    } 
   public static boolean checkPasswordComplexity(String password) {
       
       boolean uppercase= false;
       boolean smallLetter= false;
       boolean digit= false;
       boolean specialChar= false;
       boolean length= false;
       for (int p=0; p<password.length(); p++) {
           if (password.charAt(p) >=65 && password.charAt(p)<=90) {
               uppercase= true;
           }
           if (password.charAt(p)>=97 && password.charAt(p)<=122) {
               smallLetter= true;
           }
           if (password.charAt(p)>=48 && password.charAt(p)<=57) {
               digit= true;
           }
           if (password.charAt(p)>=33 && password.charAt(p)<=47 || password.charAt(p)>=58 && password.charAt(p)<=64 || password.charAt(p)>=91 && password.charAt(p)<=96 || password.charAt(p)>=123 && password.charAt(p)<=126) {
               specialChar= true;
           }
           if (password.length()<=8) {
              length=true; 
           }
           if (uppercase && smallLetter && digit && specialChar && length == true) {
               System.out.println("Password successfully captured");
           }
           else
           {
       System.out.println("Password is not correctly formatted, please ensure that your password contains a capital letter, a number, a special character and must be atleast 8 characters long");
        return false;
       
       
       }
   }
        return false;
        }
   public static String registerUser (String username, String password) {
       
       if (checkUserName(username)&& checkPasswordComplexity(password)==true){
           
           System.out.println("You are successfully registered");
       }
       else
       {
            System.out.println("Incorrect username && password");{
           return "you are registered";
       }
       }
        return null;
       }
     public static boolean logInUser (String userName, String Password) {
     
         String logPass=input.nextLine();
         
         boolean logUserName= false;
         boolean logPassword= false;
         
         if(userName.equals(userName)) {
             
             logUserName= true;
         }
         if (logUserName && logPassword) {
             System.out.println("Welcome back, it is great to see you again");
         }
         else{
             System.out.println("Username or password incorrect, please try again");
         }  
        return true || false;
         }
     public static boolean returnLoginStatus (String user, String Pass, String inUser, String inPass) {
         if (inUser.equals(user) && inPass.equals(Pass)==true) {
             System.out.println("A successful login");
             return true;
         }
         else {
             System.out.println("A failed login");
         }
        return false;
     }
     }      
   

   
    

